<?php
namespace app\api\controller\v1;
use think\Request;
use app\index\model\User as Users;
use app\index\model\UserInfo;

class Register{
    //获取学校信息
    public function getSchoolInfo(){
        $userInfo = new UserInfo();
        $user = new Users();
        $schoolData = $userInfo->where(['type'=>1])->select();
        //获取可以使用的学校
        $res['school'][] = '请选择';
        $res['schoolId'][] = 0;
        foreach($schoolData as $k=>$v){
            $one = $user->find($v->uid);
            if($one->status == 1 && $one->is_delete == 0 && $one->is_apply == 1){
                $res['school'][] = $v->name;
                $res['schoolId'][] = $v->id;
            }
        }
        return json($res);
    }

    //获取学院信息
    public function getInstituteInfo(Request $request){
        $id = $request->param('id');
        $userInfo = new UserInfo();
        $user = new Users();    
        $instituteData = $userInfo->where(['type'=>2,'tid'=>$id])->select();
        //获取可以使用的学院
        $res['institute'][] = '请选择';
        $res['instituteId'][] = 0;
        foreach($instituteData as $k=>$v){
            $one = $user->find($v->uid);
            if($one->status == 1 && $one->is_delete == 0 && $one->is_apply == 1){
                $res['institute'][] = $v->name;
                $res['instituteId'][] = $v->id;
            }
        }
        return json($res);
    }
}

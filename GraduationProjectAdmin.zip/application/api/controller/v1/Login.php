<?php
namespace app\api\controller\v1;
use think\Request;
use app\index\model\Admin;
use app\index\model\User as Users;

class Login{
    public function checkLogin(Request $request){
        $data = $request->param();  
        $status = 0;
        $resault = '';
       
        //构造查询条件
        $map = [
            'username' => $data['username'],
            'password' => md5($data['password'])
        ];
        
        //查询用户信息
        $user = Users::get($map);
        if($user == null){
                $resault = '用户名或密码错误！';
        }else if($user->is_apply == 0){
                $resault = '该账号审核进行中，暂时无法登录！';
        }else if($user->status == 0){
                $resault = '该账号已被禁用，无法登录！';
        }else if($user->is_delete == 1){
                $resault = '该账号已被删除，无法登录！';
        }else{
            if($user->type == 4){
                $status = 1;
                $resault = '登陆成功！';
            }else{
                $resault = '用户名或密码错误！';
            }
        }
        $res['status'] = $status;
        $res['message'] = $resault;

        return json($res);
    }
}

<?php
/**
 * gp_user表的验证器
 */

namespace app\common\validate;
use think\Validate;

class User extends Validate
{
    protected $rule = [
        'phone|手机号'=>[
            'require'=>'require',
            'mobile'=>'mobile',
            'unique'=>'gp_user',//该字段必须在gp_user表中唯一的
            'number'=>'number',
        ],
        'password|密码'=>[
            'require'=>'require',
            'alphaNum'=>'alphaNum',
            'length'=>'6,20',
            'confirm'=>'confirm'//自动与password_confirm字段进行相等校验
        ],
        'name|姓名'=>[
            'require'=>'require',
            'length'=>'5,20',
            'chsAlphaNum'=>'chsAlphaNum'//仅允许汉字字母数字
        ],
        'email|邮箱'=>[
            'require'=>'require',
            'email'=>'email',
            'unique'=>'gp_user'//该字段必须在gp_user表中唯一的
        ]
    ];

}



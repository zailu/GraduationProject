<?php
/**
 *基础控制器
 *必须继承自Think\Controller.php
 */ 
namespace app\common\controller;
use think\Controller;
use think\Session;

class Base extends Controller
{
    /**
     * 初始化方法
     * 创建常量，公共方法
     * 在所有的方法之前被调用
     */
    protected function initialize()
    {
        parent::initialize();
    }

    //判断用户是否登录
    protected function isLogin()
    {
        if(empty(session::get('user_id'))){
            $this->error('用户未登录，无权访问！',url('user/login'));
        }
    }

    //防止用户重复登录
    protected function reLog()
    {
        if(!empty(session::get('user_id'))){
            $this->error('用户已登录，请退出后再次登录！',url('index/index'));
        }
    }
}
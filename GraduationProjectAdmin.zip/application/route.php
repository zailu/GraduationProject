<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------


// return [
//     '__pattern__' => [
//         'name' => '\w+',
//     ],
//     '[hello]'     => [
//         ':id'   => ['index/hello', ['method' => 'get'], ['id' => '\d+']],
//         ':name' => ['index/hello', ['method' => 'post']],
//     ],

// ];




//引入动态注册类
use think\Route;

//登录校验
Route::post('login','api/v1.Login/checkLogin');
//注册-获取所有学校信息
Route::post('Register/getSchoolInfo','api/v1.Register/getSchoolInfo');
//注册-获取对应学院的信息
Route::post('Register/getInstituteInfo','api/v1.Register/getInstituteInfo');




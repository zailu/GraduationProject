<?php
namespace app\index\controller;
use app\common\controller\Base;//导入公共控制器
use app\index\model\Admin;
use app\index\model\User;
use think\Session;

class Index extends Base
{
    public function index()
    {
        $this->isLogin();//判断用户是否登录
        $this->assign([
            'title'=>'毕设后台管理系统',
            'keywords'=>'毕设',
            'desc'=>'学生毕设管理后台'
        ]);//设置tdk
        if(Session::get('power') == 0){
            $admin = Admin::get(session::get('user_id'));
            $this->assign([
                'login_count'=>$admin->login_count,
                'login_time'=>$admin->login_time
            ]);
        }else{
            $user = User::get(session::get('user_id'));
            $this->assign([
                'username'=>$user->username
            ]);
        }

        return $this->view->fetch();
    }
}

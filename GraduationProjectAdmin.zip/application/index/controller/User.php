<?php
namespace app\index\controller;
use app\common\controller\Base;//导入公共控制器
use think\Request;
use app\index\model\Admin;
use app\index\model\User as Users;
use app\index\model\UserInfo;
use think\Session;

class User extends Base
{
    //登录界面
    public function login()
    {
        $this->reLog();
       return $this->view->fetch();
    }

    //验证管理员登录
    public function checkLogin(Request $request)
    {
       $status = 0;
       $resault = '';
       $data = $request->param();

       //创建验证规则
       $rule = [
           'name|用户名'=>'require',
           'password|密码'=>'require',
           'verify|验证码'=>'require|captcha'
       ];

       //自定义验证失败的提示信息
       $msg = [
           'name'=>['require'=>'用户名不能为空，请填写！'],
           'password'=>['require'=>'密码不能为空，请填写！'],
           'verify'=>['require'=>'验证码不能为空，请填写！','captcha'=>'验证码填写错误，请重新输入！']
       ];
       //进行验证
       $resault = $this->validate($data,$rule,$msg);
       
       if($resault === true){
           //构造查询条件
           $map = [
               'username' => $data['name'],
               'password' => md5($data['password'])
           ];
           //查询用户信息
           $user = Admin::get($map);
           if($user == null){
               $resault = '用户名或密码错误！';
           }else if($user->status == 1){
                $status = 1;
                $resault = '验证通过,点击【确定】进入个人中心！';
                //设置用户登录信息
                Session::set('user_id',$user->id);
                Session::set('user_info',$user->getData());
                //设置登录用户权限级别
                 Session::set('power',0);
                //用户登录次数+1
                $admin = Admin::get($user->id);
                $login_count = $admin->login_count;
                $admin->login_count=$login_count+1;
                $admin->login_time = time();
                $admin->save();
           }else{
            $resault = '该账号已被禁用，无法登录！';
           }
        }

       return ['status'=>$status,'message'=>$resault,'data'=>$data];
    }

    //验证用户登录
    public function checkUserLogin(Request $request)
    {
       $status = 0;
       $resault = '';
       $data = $request->param();

       //创建验证规则
       $rule = [
           'name|用户名'=>'require',
           'password|密码'=>'require',
           'verify|验证码'=>'require|captcha'
       ];

       //自定义验证失败的提示信息
       $msg = [
           'name'=>['require'=>'用户名不能为空，请填写！'],
           'password'=>['require'=>'密码不能为空，请填写！'],
           'verify'=>['require'=>'验证码不能为空，请填写！','captcha'=>'验证码填写错误，请重新输入！']
       ];
       //进行验证
       $resault = $this->validate($data,$rule,$msg);
       
       if($resault === true){
           //构造查询条件
           $map = [
               'username' => $data['name'],
               'password' => md5($data['password'])
           ];
           //查询用户信息
           $user = Users::get($map);
           if($user == null){
                $resault = '用户名或密码错误！';
           }else if($user->is_apply == 0){
                $resault = '该账号审核进行中，暂时无法登录！';
           }else if($user->status == 0){
                $resault = '该账号已被禁用，无法登录！';
           }else if($user->is_delete == 1){
                $resault = '该账号已被删除，无法登录！';
           }else{
                $status = 1;
                $resault = '验证通过,点击【确定】进入个人中心！';
                //设置用户登录信息
                Session::set('user_id',$user->id);
                Session::set('user_info',$user->getData());
                //设置登录用户权限级别
                Session::set('power',$user->type);
           }
        }

       return ['status'=>$status,'message'=>$resault,'data'=>$data];
    }


    //退出
    public function logout()
    {
       //注销session
       Session::delete('user_id');
       Session::delete('user_info');
       $this->success('退出成功，正在返回登录界面！','user/login');
    }

    //管理员列表
    public function adminList()
    {
        $this->assign([
            'title'=>'管理员列表',
            'keywords'=>'毕设管理员列表',
            'desc'=>'学生毕设管理后台管理员列表'
        ]);//设置tdk
        $this->view->count = Admin::count();
        if(Session::get('user_id') == 1){
            $list = Admin::all(['is_delete'=>0]);
        }else{
            $list = [Session::get('user_info')];
        }

        $this->assign('list',$list);
        //渲染管理员列表模板
        return $this->view->fetch('admin_list');
    }

    //管理员状态变更
    public function setStatus(Request $request)
    {
        $user_id = $request->param('id');
        $resault = Admin::get($user_id);
        if($resault->getData('status') == 1){
            Admin::update(['status'=>0],['id'=>$user_id]);
        }else{
            Admin::update(['status'=>1],['id'=>$user_id]); 
        }
    }


    //渲染添加操作
    public function adminAdd(Request $request)
    {
        $this->assign([
            'title'=>'添加管理员',
            'kewords'=>'编辑管理员信息',
            'desc'=>'编辑管理员信息'
        ]);
        return $this->view->fetch('admin_add');
    }

    //检查用户名是否可用
    public function checkUserName(Request $request)
    {
        $userName = trim($request->param('username'));
        $status = 1;
        $message = "用户名可用";
        if(Admin::get(['username'=>$userName])){
            $status = 0;
            $message = "用户名重复，请重新填写！";
        }
        return ['status'=>$status,'message'=>$message];
    }

    //检查邮箱是否可用
    public function checkUserEmail(Request $request)
    {
        $userEmail = trim($request->param('email'));
        $status = 1;
        $message = "邮箱可用";
        if(Admin::get(['email'=>$userEmail])){
            $status = 0;
            $message = "邮箱重复，请重新填写！";
        }
        return ['status'=>$status,'message'=>$message];
    }    


    //新增数据操作
    public function addUser(Request $request)
    {
        $data = $request->param();
        $status = 0;
        
        $rule = [
            'username|用户名'=>'require|min:3|max:10',
            'password|密码'=>'require|min:3|max:10',
            'email|邮箱'=>'require|email'
        ];

        $msg = [
            'username'=>['require'=>'用户名不能为空，请填写！','min'=>'用户名不得小于3位','max'=>'用户名不得大于10位'],
            'password'=>['require'=>'密码不能为空，请填写！','min'=>'密码不得小于3位','max'=>'密码不得大于10位'],
            'email'=>['require'=>'邮箱不能为空，请填写！','email'=>'邮箱格式填写错误，请重新输入！']
        ];
        $resault = $this->validate($data,$rule,$msg);
        if($resault === true){
            //查询用户名和邮箱
            $newNameId = Admin::get(['username'=>$data['username']])['id'];
            $newEmailId = Admin::get(['email'=>$data['email']])['id'];
            if(empty($newNameId)){
                if(empty($newEmailId)){
                    $data['role'] = 2;
                    $data['create_time'] = time();
                    $data['password'] = md5($data['password']);
                    $user = Admin::create($data);
                    if($user === null){
                        $resault = "添加失败，请重试！";
                    }else{
                        $status = 1;
                        $resault = "添加成功！";
                    }
                }else{
                    $resault = "邮箱已存在，请重新输入!";
                }
            }else{
                $resault = "用户名已存在，请重新输入!";
            }
            
        }

        return ['status'=>$status,'message'=>$resault];
    }



    //渲染编辑管理员界面
    public function adminEdit(Request $request)
    {
        $user_id = $request->param('id');
        $resault = Admin::get($user_id);
        $this->assign([
            'title'=>'编辑管理员信息',
            'kewords'=>'编辑管理员信息',
            'desc'=>'编辑管理员信息',
            'user_info'=>$resault->getData()
        ]);
        return $this->view->fetch('admin_edit');
    }

    //更新数据操作
    public function editUser(Request $request)
    {
        $data = $request->param();
        $id = $request->param('id');

        $rule = [
            'password|密码'=>'require|min:3|max:10',
            'email|邮箱'=>'require|email'
        ];
        $status = 0;
        $msg = [
            'password'=>['require'=>'密码不能为空，请填写！','min'=>'密码不得小于3位','max'=>'密码不得大于10位'],
            'email'=>['require'=>'邮箱不能为空，请填写！','email'=>'邮箱格式填写错误，请重新输入！']
        ];
        $resault = $this->validate($data,$rule,$msg);
        
        $newEmailId = Admin::get(['email'=>$data['email']])['id'];
        if($resault === true){
            if($newEmailId && $newEmailId!=$id){
                $status = 0;
                $resault = "邮箱已存在请重新修改！";
            }else{
                $data['password'] = md5($data['password']);
                $user = Admin::update(['password'=>$data['password'],'email'=>$data['email'],'update_time'=>time()],['id'=>$id]);
                if($user === null){
                    $status = 0;
                    $resault = "修改失败，请重试！";
                }else{
                    $status = 1;
                    $resault = "修改成功！";
                }
            }
        }

        return ['status'=>$status,'message'=>$resault];
    }

     //删除数据操作
     public function deleteUser(Request $request)
     {
        $user_id = $request->param('id');
        Admin::update(['is_delete'=>1],['id'=>$user_id]);
        Admin::destroy($user_id);
    }   

    //用户个人中心
    public function userCenter(Request $request){
        $userId = $request->param('id');
        $user = (new Users())->find($userId);
        $userInfo = (new UserInfo())->where(['uid'=>$userId])->find();
 
        $data['id'] = $user->id;
        $data['username'] = $user->username;
        $data['password'] = $user->password;
        $data['name'] = $userInfo->name;
        $data['phone'] = $userInfo->phone;
        $data['email'] = $userInfo->email;
        $data['address'] = json_decode($userInfo->address,true);
        $data['job_id'] = $userInfo->job_id;
        $data['student_id'] = $userInfo->student_id;
        $data['type'] = $userInfo->type;
        $this->assign([
            'data'=>$data
        ]);
        return $this->fetch();
    }

    //用户中心更改
    public function userCenterEdit(Request $request){
        $newData = $request->param(); 
        // return ['status'=>0,'message'=>'hehe'];
        $oldUser = (new Users())->find($newData['id']);
        $oldPassword = $oldUser->password;
        $oldUserInfo = (new UserInfo())->where(['uid'=>$newData['id']])->find();
        
        //验证规则
        if($oldUser->type == 1){
            $rule1 = [
                'name|学校名'=>'require',
                'province|省份'=>'require',
                'city|市'=>'require',
                'area|区'=>'require',
                'phone|手机号'=>'require|number|max:11',
                'email|邮箱'=>'require|email'
            ];
            $msg1 = [    
                'name'=>['require'=>'学校名不能为空，请填写！'],
                'province'=>['require'=>'省份不能为空，请填写！'],
                'city'=>['require'=>'市不能为空，请填写！'],
                'area'=>['require'=>'地区/县不能为空，请填写！'],
                'phone'=>['require'=>'手机号不能为空，请填写！','number'=>'手机号格式错误，请重新填写！','max'=>'手机号不得超过11位！'],
                'email'=>['require'=>'邮箱不能为空，请填写！','email'=>'邮箱格式填写错误，请重新输入！']
            ];
        }elseif($oldUser->type == 2){
            
            $rule1 = [
                'name|学院名'=>'require',
                'phone|手机号'=>'require|number|max:11',
                'email|邮箱'=>'require|email'
            ];
            $msg1 = [    
                'name'=>['require'=>'学院名不能为空，请填写！'],
                'phone'=>['require'=>'手机号不能为空，请填写！','number'=>'手机号格式错误，请重新填写！','max'=>'手机号不得超过11位！'],
                'email'=>['require'=>'邮箱不能为空，请填写！','email'=>'邮箱格式填写错误，请重新输入！']
            ];
        }elseif($oldUser->type == 3){
            $rule1 = [
                'name|老师名'=>'require',
                'job_id|老师工号'=>'require',
                'phone|手机号'=>'require|number|max:11',
                'email|邮箱'=>'require|email'
            ];
            $msg1 = [    
                'name'=>['require'=>'老师名不能为空，请填写！'],
                'job_id'=>['require'=>'老师工号不能为空，请填写！'],
                'phone'=>['require'=>'手机号不能为空，请填写！','number'=>'手机号格式错误，请重新填写！','max'=>'手机号不得超过11位！'],
                'email'=>['require'=>'邮箱不能为空，请填写！','email'=>'邮箱格式填写错误，请重新输入！']
            ];
        }elseif($oldUser->type == 4){
            $rule1 = [
                'name|学生名'=>'require',
                'student_id|学生学号'=>'require',
                'phone|手机号'=>'require|number|max:11',
                'email|邮箱'=>'require|email'
            ];
            $msg1 = [    
                'name'=>['require'=>'学生名不能为空，请填写！'],
                'student_id'=>['require'=>'学生学号不能为空，请填写！'],
                'phone'=>['require'=>'手机号不能为空，请填写！','number'=>'手机号格式错误，请重新填写！','max'=>'手机号不得超过11位！'],
                'email'=>['require'=>'邮箱不能为空，请填写！','email'=>'邮箱格式填写错误，请重新输入！']
            ];
        }
        $rule2 = [
            'password|密码'=>'require|min:3|max:10'
        ];
        $msg2 = [
            'password'=>['require'=>'密码不能为空，请填写！','min'=>'密码不得小于3位','max'=>'密码不得大于10位']
        ];

        $userInfo = (new UserInfo())->where(['email'=>$newData['email']])->find();

        //先验证邮箱
        if(!empty($userInfo->id) && $userInfo->id != $oldUserInfo->id){
            $resault = "邮箱已存在，请重新输入!";
            return ['status'=>0,'message'=>$resault];
        }
                
        $resault1 = $this->validate($newData,$rule1,$msg1);
        $resault2 = $this->validate($newData,$rule2,$msg2);

        if($resault1 === true){
            if($resault2 === '密码不得大于10位'){               
                if($oldPassword == $newData['password']){
                    //密码没有修改，其他验证通过
                    // return ['status'=>0,'message'=>$oldUserInfo->name];
                    $oldUserInfo->name = $newData['name'];
                    $oldUserInfo->phone = $newData['phone'];
                    $oldUserInfo->email = $newData['email'];
                    if($oldUser->type == 1){
                        $tmpArr = [$newData['province'],$newData['city'],$newData['area']];
                        $oldUserInfo->address = json_encode($tmpArr,JSON_UNESCAPED_UNICODE);
                    }elseif($oldUser->type == 3){
                        $oldUserInfo->job_id = $newData['job_id'];
                    }elseif($oldUser->type == 4){
                        $oldUserInfo->student_id = $newData['student_id'];
                    }
                    $oldUserInfo->save();
                    return ['status'=>1,'message'=>'修改成功！'];
                }else{
                    //密码修改但密码大于10位了
                    return ['status'=>0,'message'=>$resault2];
                }
            }else if($resault2 === true){
                //所有验证通过
                // return ['status'=>1,'message'=>'好极了！'];

                //修改密码
                $oldUser->password = md5($newData['password']);
                $oldUser->save();
                //修改用户信息
                $oldUserInfo->name = $newData['name'];
                $oldUserInfo->phone = $newData['phone'];
                $oldUserInfo->email = $newData['email'];
                if($oldUser->type == 1){
                    $tmpArr = [$newData['province'],$newData['city'],$newData['area']];
                    $oldUserInfo->address = json_encode($tmpArr,JSON_UNESCAPED_UNICODE);
                }elseif($oldUser->type == 3){
                    $oldUserInfo->job_id = $newData['job_id'];
                }elseif($oldUser->type == 4){
                    $oldUserInfo->student_id = $newData['student_id'];
                }
                $oldUserInfo->save();
                return ['status'=>1,'message'=>'修改成功！'];     
            }else{
                //密码为空或密码小于3位
                return ['status'=>0,'message'=>$resault2];
            }                     
        }else{
            return ['status'=>0,'message'=>$resault1];
        }
    }
}

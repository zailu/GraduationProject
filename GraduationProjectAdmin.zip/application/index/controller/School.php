<?php
namespace app\index\controller;
use app\common\controller\Base;//导入公共控制器
use app\index\model\User;
use app\index\model\UserInfo;
use think\Request;

class School extends Base
{
    //学校申请列表
    public function schoolApply(Request $request)
    {
        $flag = 0;
        $kw = urldecode($request->param('kw')); 
        if($kw != null){
            $flag = 1;
            //找到所有学校信息like的
            $schoolData = (new UserInfo())->where(['type'=>'1'])->where('name|phone|email','like','%'.$kw.'%')->select();
            $list = [];
            foreach($schoolData as $k=>$v){
                $user = (new User())->find($v['uid']);
                if($user->is_apply == 0 && $user->is_delete == 0){
                    $list[$k] = $v;
                    $list[$k]['id'] =  $user->id;
                    $list[$k]['schoolName'] = $v->name;
                    $list[$k]['username'] = $user->username;
                    $list[$k]['apply_time'] = $user->apply_time;
                    $list[$k]['is_apply'] = $user->is_apply;
                }
            }
            $dataCount = count($list);
        }else{
            $user = new User();
            $userdata = $user->where(['type'=>'1','is_apply'=>'0','is_delete'=>'0'])->select();
            $dataCount = count($userdata);
            $list = $user->where(['type'=>'1','is_apply'=>'0','is_delete'=>'0'])->paginate(10)->each(function($v,$k){
                $v['schoolName'] = (new UserInfo())->where(['type'=>'1','uid'=>$v->id])->find()->name;
            });
        }
        $this->assign([
            'dataCount'=>$dataCount,
            'list'=>$list,
            'flag'=>$flag
        ]);
        return $this->fetch();
    }

    //审核通过
    public function applyYes(Request $request)
    {
        $user = new User();
        $id = $request->param('id');
        //将申请状态和注册时间修改
        $user->save([
            'is_apply'=>1,
            'register_time'=>time()
        ],['id'=>$id]);
    }

    //审核失败
    public function applyNo(Request $request)
    {
        $user = new User();
        $id = $request->param('id');
        $user->save([
            'is_apply'=>2
        ],['id'=>$id]);
    }   
    
    //查看审核内容
    public function schoolInfo(Request $request)
    {
        $id = $request->param('id');
        //取出申请的具体信息
        $userInfo = new UserInfo();
        $data = $userInfo->where(['uid'=>$id])->find();
        $data['address'] = json_decode($data['address'],true);

        //加入账户名和申请时间
        $user = new User();
        $data['username'] = $user->find($id)->username;
        $data['apply_time'] = $user->find($id)->apply_time;

        //渲染到view
        $this->assign([
            'data'=>$data
        ]);
        return $this->fetch();
    }

    //学校列表
    public function schoolList(Request $request)
    {
        //搜索条件接收与初始化
        $flag = 0;
        $kw = urldecode($request->param('kw'));
        $user = new User();
        $userInfo = new UserInfo();
        if($kw != null){
            $flag = 1;
            //找到所有学校信息like的
            $instituteData = (new UserInfo())->where(['type'=>'1'])->where('name|phone|email','like','%'.$kw.'%')->select();
            $list = [];
            foreach($instituteData as $k=>$v){
                $user = (new User())->find($v['uid']);
                if($user->is_apply == 1 && $user->is_delete == 0){
                    $list[$k] = $v;
                    $list[$k]['id'] =  $user->id;
                    $list[$k]['schoolName'] = $v->name;
                    $list[$k]['username'] = $user->username;
                    $list[$k]['register_time'] = $user->register_time;
                    $list[$k]['status'] = $user->status;
                }
            }
            $dataCount = count($list);
        }else{   
            //显示所有数据   
            $userdata = $user->where(['type'=>'1','is_apply'=>'1','is_delete'=>'0'])->select();
            $dataCount = count($userdata);
            $list = $user->where(['type'=>'1','is_apply'=>'1','is_delete'=>'0'])->paginate()->each(function($v,$k){
                $v['schoolName'] = (new UserInfo())->where(['uid'=>$v->id])->find()->name;
            });
        }
        $this->assign([
            'list'=>$list,
            'dataCount'=>$dataCount,
            'flag'=>$flag
        ]);
        return $this->fetch();
    }  

    //添加学校页面
    public function schoolAdd()
    {
        return $this->fetch();
    }

    //检查用户名是否重复
    public function checkUserName(Request $request)
    {
        $name = $request->param('name');

        //创建User模型
        $user = new User();
        $one = $user->where(['username'=>$name])->find();
        if($one->id){
            $status = 0;
            $message = "用户名重复，请重新填写！";
        }else{
            $status = 1;
            $message = "用户名可用";
        }
        return ['status'=>$status,'message'=>$message];
    }

    //检查邮箱是否重复
    public function checkUserEmail(Request $request)
    {
        $email = $request->param('email');
        //创建UserInfo模型
        $userInfo = new UserInfo();
        $one = $userInfo->where(['email'=>$email])->find();
        if($one->id){
            $status = 0;
            $message = "邮箱重复，请重新填写！";
        }else{
            $status = 1;
            $message = "邮箱可用";
        }
        return ['status'=>$status,'message'=>$message];
    }    



    //添加学校
    public function addSchool(Request $request)
    {
        $data = $request->param();
        
        //验证规则
        $status = 0;
        $resault = '新增失败，请重试！';
        $rule = [
            'username|用户名'=>'require|min:3|max:10',
            'password|密码'=>'require|min:3|max:10',
            'name|学校名'=>'require',
            'province|省份'=>'require',
            'city|市'=>'require',
            'area|区'=>'require',
            'phone|手机号'=>'require|number',
            'email|邮箱'=>'require|email'
        ];

        $msg = [
            'username'=>['require'=>'用户名不能为空，请填写！','min'=>'用户名不得小于3位','max'=>'用户名不得大于10位'],
            'password'=>['require'=>'密码不能为空，请填写！','min'=>'密码不得小于3位','max'=>'密码不得大于10位'],
            'name'=>['require'=>'学校名不能为空，请填写！'],
            'province'=>['require'=>'省份不能为空，请填写！'],
            'city'=>['require'=>'市不能为空，请填写！'],
            'area'=>['require'=>'地区/县不能为空，请填写！'],
            'phone'=>['require'=>'手机号不能为空，请填写！','number'=>'手机号格式错误，请重新填写！'],
            'email'=>['require'=>'邮箱不能为空，请填写！','email'=>'邮箱格式填写错误，请重新输入！']
        ];
        $resault = $this->validate($data,$rule,$msg);

        if($resault === true){
             //查询用户名和邮箱
             $user = (new User())->where(['username'=>$data['username']])->find();
             $userInfo = (new UserInfo())->where(['email'=>$data['email']])->find();
             if(empty($user->id)){
                 if(empty($userInfo->id)){
                    //新增账户
                    $account = new User();
                    $account->username = $data['username'];
                    $account->password = md5($data['password']);
                    $account->type = 1;
                    $account->is_apply = 1;
                    $account->apply_time = time();
                    $account->register_time = time();
                    $account->status = $data['status'];
                    $account->save();

                    $uid = $account->id;
                    //新增用户信息
                    $accountInfo = new UserInfo();
                    $accountInfo->name = $data['name'];
                    $accountInfo->phone = $data['phone'];
                    $accountInfo->email = $data['email'];
                    $tmpArr = [$data['province'],$data['city'],$data['area']];
                    $accountInfo->address = json_encode($tmpArr,JSON_UNESCAPED_UNICODE);
                    $accountInfo->type = 1;
                    $accountInfo->uid = $uid;
                    if($accountInfo->save()){
                        $resault = '新增成功！';
                        $status = 1;
                    }else{
                        $resault = '新增失败，请重试！';
                    }
                 }else{
                     $resault = "邮箱已存在，请重新输入!";
                 }
             }else{
                 $resault = "用户名已存在，请重新输入!";
             }
        }
        return ['status'>$status,'message'=>$resault];
    }    

    //更改学校启用状态
    public function setStatus(Request $request)
    {   
        $id = $request->param('id');
        $user = new User();
        $one = $user->find($id);
        if($one->status == 1){
            $one->status = 0;
        }else{
            $one->status = 1;
        }
        $one->save();
    }

    //渲染编辑界面
    public function schoolEdit(Request $request)
    {
        $id = $request->param('id');
        $user = (new User())->find($id);
        $data['id'] = $id;
        $data['username'] = $user->username;
        $data['password'] = $user->password;
        $userInfo = (new UserInfo)->where(['uid'=>$id])->find();
        $data['name'] = $userInfo->name;
        $data['phone'] = $userInfo->phone;
        $data['email'] = $userInfo->email;
        $tmpArr = json_decode($userInfo->address,true);
        $data['province'] = $tmpArr[0];
        $data['city'] = $tmpArr[1];
        $data['area'] = $tmpArr[2];
        $this->assign([
            'data'=>$data
        ]);
        return $this->fetch();
    }

    //学校信息编辑
    public function editSchool(Request $request)
    {
        $newData = $request->param(); 

        $oldUser = (new User())->find($newData['id']);
        $oldPassword = $oldUser->password;
        $oldUserInfo = (new UserInfo())->where(['uid'=>$newData['id']])->find();
        
        //验证规则
        $rule1 = [
            'name|学校名'=>'require',
            'province|省份'=>'require',
            'city|市'=>'require',
            'area|区'=>'require',
            'phone|手机号'=>'require|number|max:11',
            'email|邮箱'=>'require|email'
        ];
        $msg1 = [    

            'name'=>['require'=>'学校名不能为空，请填写！'],
            'province'=>['require'=>'省份不能为空，请填写！'],
            'city'=>['require'=>'市不能为空，请填写！'],
            'area'=>['require'=>'地区/县不能为空，请填写！'],
            'phone'=>['require'=>'手机号不能为空，请填写！','number'=>'手机号格式错误，请重新填写！','max'=>'手机号不得超过11位！'],
            'email'=>['require'=>'邮箱不能为空，请填写！','email'=>'邮箱格式填写错误，请重新输入！']
        ];
        $rule2 = [
            'password|密码'=>'require|min:3|max:10'
        ];
        $msg2 = [
            'password'=>['require'=>'密码不能为空，请填写！','min'=>'密码不得小于3位','max'=>'密码不得大于10位']
        ];
        $userInfo = (new UserInfo())->where(['email'=>$newData['email']])->find();

        //先验证邮箱
        if(!empty($userInfo->id) && $userInfo->id != $oldUserInfo->id){
            $resault = "邮箱已存在，请重新输入!";
            return ['status'=>0,'message'=>$resault];
        }
                
        $resault1 = $this->validate($newData,$rule1,$msg1);
        $resault2 = $this->validate($newData,$rule2,$msg2);

        if($resault1 === true){
            if($resault2 === '密码不得大于10位'){               
                if($oldPassword == $newData['password']){
                    //密码没有修改，其他验证通过
                    $oldUserInfo->name = $newData['name'];
                    $oldUserInfo->phone = $newData['phone'];
                    $oldUserInfo->email = $newData['email'];
                    $tmpArr = [$newData['province'],$newData['city'],$newData['area']];
                    $oldUserInfo->address = json_encode($tmpArr,JSON_UNESCAPED_UNICODE);
                    $oldUserInfo->save();
                    return ['status'=>1,'message'=>'修改成功！'];
                }else{
                    //密码修改但密码大于10位了
                    return ['status'=>0,'message'=>$resault2];
                }
            }else if($resault2 === true){
                //所有验证通过
                // return ['status'=>1,'message'=>'好极了！'];

                //修改密码
                $oldUser->password = md5($newData['password']);
                $oldUser->save();
                //修改用户信息
                $oldUserInfo->name = $newData['name'];
                $oldUserInfo->phone = $newData['phone'];
                $oldUserInfo->email = $newData['email'];
                $tmpArr = [$newData['province'],$newData['city'],$newData['area']];
                $oldUserInfo->address = json_encode($tmpArr,JSON_UNESCAPED_UNICODE);
                $oldUserInfo->save();
                return ['status'=>1,'message'=>'修改成功！'];     
            }else{
                //密码为空或密码小于3位
                return ['status'=>0,'message'=>$resault2];
            }                     
        }else{
            return ['status'=>0,'message'=>$resault1];
        }
    }

    //学校账号删除
    public function delete(Request $request)
    {
        $id = $request->param('id');
        $user = (new User())->find($id);
        $user->is_delete = 1;
        $user->save();
        return ['msg'=>'删除学校成功！'];
    }
}
<?php
namespace app\index\controller;
use app\common\controller\Base;//导入公共控制器
use app\index\model\User;
use app\index\model\UserInfo;
use think\Request;
use think\DB;

class Student extends Base
{
    //学生账号申请页面渲染
    public function studentApply(Request $request)
    {
        $where = [];
        $wherein = [];
        if(session('power') == 1){
            $schoolInfoId = (new UserInfo())->where(['uid'=>session('user_id')])->find()->id;
            $instituteInfo = (new UserInfo())->where(['tid'=>$schoolInfoId])->select();
            foreach($instituteInfo as $k=>$v){
                $wherein[] = $v->id;
            }
        }else if(session('power') == 2){
            $instituteInfo = (new UserInfo())->where(['uid'=>session('user_id')])->find();
            $where = ['tid'=>$instituteInfo->id];
        }

        $flag = 0;
        $kw = urldecode($request->param('kw')); 
        if($kw != null){
            $flag = 1;
            //找到所有老师信息like的
            if(session('power') == 1){
                $studentData = (new UserInfo())->where(['type'=>'4'])->where('name|phone|email|student_id','like','%'.$kw.'%')->whereIn('tid',$wherein,'AND')->select();
            }else{
                $studentData = (new UserInfo())->where(['type'=>'4'])->where('name|phone|email|student_id','like','%'.$kw.'%')->where($where)->select();
            }
            $list = [];
            foreach($studentData as $k=>$v){
                $user = (new User())->find($v['uid']);
                if($user->is_apply == 0 && $user->is_delete == 0){
                    $list[$k] = $v;
                    $list[$k]['id'] =  $user->id;
                    $list[$k]['username'] = $user->username;
                    $list[$k]['apply_time'] = $user->apply_time;
                    $list[$k]['is_apply'] = $user->is_apply;
                }
            }
            $dataCount = count($list);
        }else{
            $user = new User();
            if(session('power') == 1){
                $dataCount = count(DB::view('User','id,username,type,is_apply,apply_time,is_delete')
                ->view('UserInfo','uid,name','User.id=UserInfo.uid')
                ->where(['type'=>'4','is_apply'=>'0','is_delete'=>'0'])
                ->whereIn('tid',$wherein,'AND')
                ->select());
                $list = DB::view('User','id,username,type,is_apply,apply_time,is_delete')
                ->view('UserInfo','uid,name','User.id=UserInfo.uid')
                ->where(['type'=>'4','is_apply'=>'0','is_delete'=>'0'])
                ->whereIn('tid',$wherein,'AND')
                ->paginate();
            }else{
                $dataCount = count(DB::view('User','id,username,type,is_apply,apply_time,is_delete')
                ->view('UserInfo','uid,name','User.id=UserInfo.uid')
                ->where(['type'=>'4','is_apply'=>'0','is_delete'=>'0'])
                ->where($where)
                ->select());
                $list = DB::view('User','id,username,type,is_apply,apply_time,is_delete')
                ->view('UserInfo','uid,name','User.id=UserInfo.uid')
                ->where(['type'=>'4','is_apply'=>'0','is_delete'=>'0'])
                ->where($where)
                ->paginate();
            }
        }
        $this->assign([
            'list'=>$list,
            'dataCount'=>$dataCount,
            'flag'=>$flag
        ]);
        return $this->fetch();
    }

    //查看学生具体信息
    public function studentInfo(Request $request)
    { 
        $id = $request->param('id');
        //取出申请的具体信息
        $userInfo = new UserInfo();
        $data = $userInfo->where(['uid'=>$id])->find();

        //加入账户名和申请时间
        $user = new User();
        $data['username'] = $user->find($id)->username;
        $data['apply_time'] = $user->find($id)->apply_time;

        //加入学院信息
        $instituteInfo = (new UserInfo())->find($data->tid);
        $data['instituteName'] = $instituteInfo->name;
        //加入学校信息
        $schoolInfo = (new UserInfo())->find($instituteInfo->tid);
        $data['schoolName'] = $schoolInfo->name;
        $data['address'] = json_decode($schoolInfo->address,true);
        
        //渲染到view
        $this->assign([
            'data'=>$data
        ]);
        return $this->fetch();
    }

    //审核功能
    //审核通过
    public function applyYes(Request $request)
    {
        $user = new User();
        $id = $request->param('id');
        //将申请状态和注册时间修改
        $user->save([
            'is_apply'=>1,
            'register_time'=>time()
        ],['id'=>$id]);
    }

    //审核失败
    public function applyNo(Request $request)
    {
        $user = new User();
        $id = $request->param('id');
        $user->save([
            'is_apply'=>2
        ],['id'=>$id]);
    }      

    //学生列表
    public function studentList(Request $request)
    {
        $where = [];
        $wherein = [];
        if(session('power') == 1){
            $schoolInfoId = (new UserInfo())->where(['uid'=>session('user_id')])->find()->id;
            $instituteInfo = (new UserInfo())->where(['tid'=>$schoolInfoId])->select();
            foreach($instituteInfo as $k=>$v){
                $wherein[] = $v->id;
            }
        }else if(session('power') == 2){
            $instituteInfo = (new UserInfo())->where(['uid'=>session('user_id')])->find();
            $where = ['tid'=>$instituteInfo->id];
        }

         //搜索条件接收与初始化
         $flag = 0;
         $kw = urldecode($request->param('kw'));

        $user = new User();
        if($kw != null){
            $flag = 1;
            //找到所有学生信息like的
            if(session('power') == 1){
                $studentData = (new UserInfo())->where(['type'=>'4'])->where('name|phone|email|student_id','like','%'.$kw.'%')->whereIn('tid',$wherein,'AND')->select();
            }else{
                $studentData = (new UserInfo())->where(['type'=>'4'])->where('name|phone|email|student_id','like','%'.$kw.'%')->where($where)->select();
            }
            // $instituteData = (new UserInfo())->where(['type'=>'4'])->where('name|phone|email|student_id','like','%'.$kw.'%')->select();
            $list = [];
            foreach($studentData as $k=>$v){
                $user = (new User())->find($v['uid']);
                if($user->is_apply == 1 && $user->is_delete == 0){
                    $list[$k] = $v;
                    $list[$k]['id'] =  $user->id;
                    $list[$k]['username'] = $user->username;
                    $list[$k]['register_time'] = $user->register_time;
                    $list[$k]['status'] = $user->status;
                }
            }
            $dataCount = count($list);
        }else{
            if(session('power') == 1){
                $dataCount = count(DB::view('User','id,username,type,is_apply,register_time,is_delete,status')
                ->view('UserInfo','uid,name','User.id=UserInfo.uid')
                ->where(['type'=>'4','is_apply'=>'1','is_delete'=>'0'])
                ->whereIn('tid',$wherein,'AND')
                ->select());
                $list = DB::view('User','id,username,type,is_apply,register_time,is_delete,status')
                ->view('UserInfo','uid,name','User.id=UserInfo.uid')
                ->where(['type'=>'4','is_apply'=>'1','is_delete'=>'0'])
                ->whereIn('tid',$wherein,'AND')
                ->paginate();
            }else{
                $dataCount = count(DB::view('User','id,username,type,is_apply,register_time,is_delete,status')
                ->view('UserInfo','uid,name','User.id=UserInfo.uid')
                ->where(['type'=>'4','is_apply'=>'1','is_delete'=>'0'])
                ->where($where)
                ->select());
                $list = DB::view('User','id,username,type,is_apply,register_time,is_delete,status')
                ->view('UserInfo','uid,name','User.id=UserInfo.uid')
                ->where(['type'=>'4','is_apply'=>'1','is_delete'=>'0'])
                ->where($where)
                ->paginate();
            }      
        }
        $this->assign([
            'list'=>$list,
            'dataCount'=>$dataCount,
            'flag'=>$flag
        ]);
        return $this->fetch();
    }

    //添加学生页面渲染
    public function studentAdd()
    {
        $userInfo = new UserInfo();
        $user = new User();
        $data = $userInfo->where(['type'=>1])->select();
        //获取可以使用的学校
        foreach($data as $k=>$v){
            $one = $user->find($v->uid);
            if($one->status == 1 && $one->is_delete == 0 && $one->is_apply == 1){
                $schooldata[$k]['name'] = $v->name;
                $schooldata[$k]['id'] = $v->id;
            }
        }
        $this->assign([
            'schooldata'=>$schooldata
        ]);
        return $this->fetch();
    }   

    //联动选择学院
    public function chooseInstitute(Request $request)
    {
        $schoolId = $request->param('id');
        $user = new User();
        $data = (new UserInfo)->where(['type'=>2,'tid'=>$schoolId])->select();
        foreach($data as $k=>$v){
            $one = $user->find($v->uid);
            if($one->status == 1 && $one->is_delete == 0 && $one->is_apply == 1){
                $instituteData[$k]['name'] = $v->name;
                $instituteData[$k]['id'] = $v->id;
            }
        }
        if(empty($instituteData)){
            return ['status'=>0,'msg'=>'该学校暂无学院，请选择其他学校或为该学校创建学院！','data'=>''];
        }else{
            return ['status'=>1,'msg'=>'返回成功','data'=>$instituteData];
        }
    }

    //检查用户名是否重复
    public function checkUserName(Request $request)
    {
        $name = $request->param('name');

        //创建User模型
        $user = new User();
        $one = $user->where(['username'=>$name])->find();
        if($one->id){
            $status = 0;
            $message = "用户名重复，请重新填写！";
        }else{
            $status = 1;
            $message = "用户名可用";
        }
        return ['status'=>$status,'message'=>$message];
    }

    //检查邮箱是否重复
    public function checkUserEmail(Request $request)
    {
        $email = $request->param('email');
        //创建UserInfo模型
        $userInfo = new UserInfo();
        $one = $userInfo->where(['email'=>$email])->find();
        if($one->id){
            $status = 0;
            $message = "邮箱重复，请重新填写！";
        }else{
            $status = 1;
            $message = "邮箱可用";
        }
        return ['status'=>$status,'message'=>$message];
    }   

    //添加学生
    public function addStudent(Request $request)
    {
        $data = $request->param();
        //验证规则
        $status = 0;
        $resault = '新增失败，请重试！';
        $rule = [
            'username|用户名'=>'require|min:3|max:10',
            'password|密码'=>'require|min:3|max:10',
            'name|学生名'=>'require',
            'student_id|学生学号'=>'require',
            'phone|手机号'=>'require|number',
            'email|邮箱'=>'require|email'
        ];

        $msg = [
            'username'=>['require'=>'用户名不能为空，请填写！','min'=>'用户名不得小于3位','max'=>'用户名不得大于10位'],
            'password'=>['require'=>'密码不能为空，请填写！','min'=>'密码不得小于3位','max'=>'密码不得大于10位'],
            'name'=>['require'=>'学生名不能为空，请填写！'],
            'student_id'=>['require'=>'学生学号不能为空，请填写！'],
            'phone'=>['require'=>'手机号不能为空，请填写！','number'=>'手机号格式错误，请重新填写！'],
            'email'=>['require'=>'邮箱不能为空，请填写！','email'=>'邮箱格式填写错误，请重新输入！']
        ];
        $resault = $this->validate($data,$rule,$msg);

        if($resault === true){
             //查询用户名和邮箱
             $user = (new User())->where(['username'=>$data['username']])->find();
             $userInfo = (new UserInfo())->where(['email'=>$data['email']])->find();
             if(empty($user->id)){
                 if(empty($userInfo->id)){
                    //检查学校学院是否未选择
                    if($data['schoolid'] == 0 || $data['tid'] == 0){
                        return ['status'>0,'message'=>'学校或学院不能为空！'];
                    }

                    //新增账户
                    $account = new User();
                    $account->username = $data['username'];
                    $account->password = md5($data['password']);
                    $account->type = 4;
                    $account->is_apply = 1;
                    $account->apply_time = time();
                    $account->register_time = time();
                    $account->status = $data['status'];
                    $account->save();

                    $uid = $account->id;
                    //新增用户信息
                    $accountInfo = new UserInfo();
                    $accountInfo->name = $data['name'];
                    $accountInfo->phone = $data['phone'];
                    $accountInfo->email = $data['email'];
                    $accountInfo->type = 4;
                    $accountInfo->uid = $uid;
                    $accountInfo->student_id = $data['student_id'];
                    $accountInfo->tid = $data['tid'];
                    if($accountInfo->save()){
                        $resault = '新增成功！';
                        $status = 1;
                    }else{
                        $resault = '新增失败，请重试！';
                    }
                 }else{
                     $resault = "邮箱已存在，请重新输入!";
                 }
             }else{
                 $resault = "用户名已存在，请重新输入!";
             }
        }
        return ['status'>$status,'message'=>$resault];
    }

    //更改学生账号启用状态
    public function setStatus(Request $request)
    {
        $id = $request->param('id');
        $user = new User();
        $one = $user->find($id);
        if($one->status == 1){
            $one->status = 0;
        }else{
            $one->status = 1;
        }
        $one->save();
    }

    //编辑页面渲染
    public function studentEdit(Request $request)
    {   
        $id = $request->param('id');
        $user = (new User())->find($id);
        $data['id'] = $id;
        $data['username'] = $user->username;
        $data['password'] = $user->password;
        $userInfo = (new UserInfo)->where(['uid'=>$id])->find();
        $data['name'] = $userInfo->name;
        $data['phone'] = $userInfo->phone;
        $data['email'] = $userInfo->email;
        $data['tid'] = $userInfo->tid;
        $data['student_id'] = $userInfo->student_id;
        
        //找到对应的学院
        $data['instituteId'] = $userInfo->tid;
        $data['schoolId'] = (new UserInfo())->find($data['instituteId'])->tid;
        
        //获取可以使用的学校
        $datas = (new UserInfo())->where(['type'=>1])->select();       
        foreach($datas as $k=>$v){
            $one = (new User())->find($v->uid);
            if($one->status == 1 && $one->is_delete == 0 && $one->is_apply == 1){
                $enddata[$k]['name'] = $v->name;
                $enddata[$k]['id'] = $v->id;
            }
        }
        //获取可以使用的学院
        $datai = (new UserInfo())->where(['type'=>2])->select();       
        foreach($datai as $k=>$v){
            $one = (new User())->find($v->uid);
            if($one->status == 1 && $one->is_delete == 0 && $one->is_apply == 1){
                $idata[$k]['name'] = $v->name;
                $idata[$k]['id'] = $v->id;
            }
        }    
        $this->assign([
            'enddata'=>$enddata,
            'idata'=>$idata,
            'data'=>$data
        ]);
        return $this->fetch();
    }
    
    //编辑学生信息
    public function editStudent(Request $request)
    {
        $newData = $request->param(); 
        $oldUser = (new User())->find($newData['id']);
        $oldPassword = $oldUser->password;
        $oldUserInfo = (new UserInfo())->where(['uid'=>$newData['id']])->find();
        //验证规则
        $rule1 = [
            'name|学生名'=>'require',
            'student_id|学生学号'=>'require',
            'phone|手机号'=>'require|number',
            'email|邮箱'=>'require|email'
        ];
        $msg1 = [    
            'name'=>['require'=>'学生名不能为空，请填写！'],
            'student_id'=>['require'=>'学生学号不能为空，请填写！'],
            'phone'=>['require'=>'手机号不能为空，请填写！','number'=>'手机号格式错误，请重新填写！'],
            'email'=>['require'=>'邮箱不能为空，请填写！','email'=>'邮箱格式填写错误，请重新输入！']
        ];
        $rule2 = [
            'password|密码'=>'require|min:3|max:10'
        ];
        $msg2 = [
            'password'=>['require'=>'密码不能为空，请填写！','min'=>'密码不得小于3位','max'=>'密码不得大于10位']
        ];
        $userInfo = (new UserInfo())->where(['email'=>$newData['email']])->find();

        //先验证邮箱
        if(!empty($userInfo->id) && $userInfo->id != $oldUserInfo->id){
            $resault = "邮箱已存在，请重新输入!";
            return ['status'=>0,'message'=>$resault];
        }
        //检查学校学院是否未选择
        if($newData['schoolid'] == 0 || $newData['tid'] == 0){
            return ['status'=>0,'message'=>'学校或学院不能为空！'];
        }        
    
        // var_dump($userInfo);die; 
        $resault1 = $this->validate($newData,$rule1,$msg1);
        $resault2 = $this->validate($newData,$rule2,$msg2); 
        if($resault1 === true){         
    
            if($resault2 === '密码不得大于10位'){          
                if($oldPassword == $newData['password']){
                    //密码没有修改，其他验证通过
                    $oldUserInfo->name = $newData['name'];
                    $oldUserInfo->phone = $newData['phone'];
                    $oldUserInfo->email = $newData['email'];
                    $oldUserInfo->tid = $newData['tid'];
                    $oldUserInfo->student_id = $newData['student_id'];
                    $oldUserInfo->save();
                    return ['status'=>1,'message'=>'修改成功！'];
                }else{
                    //密码修改但密码大于10位了
                    return ['status'=>0,'message'=>$resault2];
                }
            }else if($resault2 === true){
                //所有验证通过
                // return ['status'=>1,'message'=>'好极了！'];

                //修改密码
                $oldUser->password = md5($newData['password']);
                $oldUser->save();
                //修改用户信息
                $oldUserInfo->name = $newData['name'];
                $oldUserInfo->phone = $newData['phone'];
                $oldUserInfo->email = $newData['email'];
                $oldUserInfo->tid = $newData['tid'];
                $oldUserInfo->student_id = $newData['student_id'];
                $oldUserInfo->save();
                return ['status'=>1,'message'=>'修改成功！'];     
            }else{
                //密码为空或密码小于3位
                return ['status'=>0,'message'=>$resault2];
            }                     
        }else{
            return ['status'=>0,'message'=>$resault1];
        }
    }

    //删除学生信息
    public function deleteStudent(Request $request)
    {
        $id = $request->param('id');
        $user = (new User())->find($id);
        $user->is_delete = 1;
        $user->save();
        return ['msg'=>'删除学生成功！'];
    }
}
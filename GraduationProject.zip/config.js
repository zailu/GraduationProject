exports.config = {
  configUrl: "http://gpa.com/"
};
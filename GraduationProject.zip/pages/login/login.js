// pages/login/login.js

var loginAPI = require("../../api/loginAPI");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    clearname:'',
    clearpass:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function () {

  // },

  // 跳转到注册界面
  goToRegister: function(){
    wx.navigateTo({
      url:'../register/register'
    });
  },

  // 获取用户名
  getUsername: function(e){
    console.log(e.detail.value);
    var val = e.detail.value;
    this.setData({
      username:val
    });
  },

  //获取密码
  getPassword: function(e){
    var val = e.detail.value;
    this.setData({
      password:val
    })
  },

  //提交登陆
  login: function(){
    console.log(this.data.username);
    //判断是否为空
    if(this.data.username == null || this.data.password == null){
      wx.showToast({
        title: '用户名或密码不能为空！',
        icon: 'none',
        duration: 2000,
      });
    }
    const api = loginAPI.checkLogin;
    let t = this;
    wx.request({
      url:api.url,
      data:{
        username:t.data.username,
        password:t.data.password
      },
      method:'POST',
      header:{
        'content-type': 'application/json' 
      },
      success(res){
        console.log(res);
        if(res.data.status == 1){
          wx.showToast({
            title: res.data.message,
            icon: 'none',
            duration: 2000,
            complete:function(){
              setTimeout(function(){
                wx.navigateTo({
                  url:"../index/index"
                })
              },1000);
            }
          });
        }else{
          wx.showToast({
            title: res.data.message,
            icon: 'none',
            duration: 2000,
            complete:function(){
              t.clearInputEvent();
            }
          });
        }
      },
      error(){
        wx.showToast({
          title: '网络错误请重试',
          icon: 'success',
          duration: 2000
        }) 
      }
    });
  },
  //清除输入框内的数据
  clearInputEvent: function() {
    this.setData({
      'clearname':'',
      'clearpass':''
    });
  }
})
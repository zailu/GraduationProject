//index.js
//获取应用实例
const app = getApp()
var registerAPI = require("../../api/registerAPI");
Page({
    data:{
        schoolId:[],
        school:[],
        schoolIndex:0,
        institute:[],
        instituteId:[],
        instituteIndex:0
    },
    onLoad:function(){
      //获取学校列表
      let t = this;
      const api = registerAPI.getSchoolInfo;
      wx.request({
        url:api.url,
        data:{},
        method:'POST',
        header:{
          'content-type': 'application/json' 
        },
        success:function(e){
          //获取到学校列表
          console.log(e);
          t.setData({
            schoolId:e.data.schoolId,
            school:e.data.school,
          });
        },
        error:function(){
          wx.showToast({
            title: '获取学校列表失败，请上拉刷新！',
            icon: 'none',
            duration: 2000,
          });
        }
      });
    },

    //选择学校
    bindPickerChangeSchool(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
          schoolIndex: e.detail.value
        });
        //学校id为：this.data.schoolId[e.detail.value]
        // console.log(this.data.schoolId[e.detail.value]);
        //获取学院
        let t = this;
        const api = registerAPI.getInstituteInfo;
        wx.request({
          url:api.url,
          data:{
            id:t.data.schoolId[e.detail.value]
          },
          method:'POST',
          header:{
            'content-type': 'application/json' 
          },
          success:function(res){
            //获取到学院列表
            console.log(res);
            t.setData({
              instituteId:res.data.instituteId,
              institute:res.data.institute,
            });
          },
          error:function(){
            wx.showToast({
              title: '获取学院列表失败，请上拉刷新！',
              icon: 'none',
              duration: 2000,
            });
          }
        });
      },
    //选择学院
    bindPickerChangeInstitute(e) {
      console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        instituteIndex: e.detail.value
      })
    },
    //注册表单
    formSubmit(e){
      console.log(e.detail.value);
    },
})

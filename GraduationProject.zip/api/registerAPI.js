let cf = require("../config.js");
module.exports = {
	getSchoolInfo:{
		url : cf.config.configUrl + "register/getSchoolInfo.html",
		data: {},
		method: 'POST'
	},
	getInstituteInfo:{
		url : cf.config.configUrl + "register/getInstituteInfo.html",
		data: {},
		method: 'POST'
	},
};
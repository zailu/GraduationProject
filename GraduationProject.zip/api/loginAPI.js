let cf = require("../config.js");
module.exports = {
	checkLogin:{
		url : cf.config.configUrl + "login/checkLogin.html",
		data: {},
		method: 'POST'
	}
};